#include<iostream>
#include<vector>
#include<stdio.h>
using namespace std;
void print_stat(vector<int> l[2],int lL,int stat)
{
        if(stat == 0)
                return;
        print_stat(l,l[lL][stat],stat-1);
        printf("%d",l[lL][stat]);
}
int main()
{
        int tmp,n,i;
        vector<int> f[2],l[2];
        vector<int> a[2],t[2];
        int e[2],x[2];
        int fmin,lL;

        //printf("enter the no of stations");
        scanf("%d",&n);

        //printf("enter the entry points of two stations");
        scanf("%d %d",&e[0],&e[1]);
        //printf("enter the node time of line 1");
        for(i=0;i<n;i++)
        {
                scanf("%d",&tmp);
                a[0].push_back(tmp);
        }

        //printf("enter the node time of line 2");
        for(i=0;i<n;i++)
        {
                scanf("%d",&tmp);
                a[1].push_back(tmp);
        }

        //printf("enter the crossing time of line 1");
 for(i=0;i<n-1;i++)
        {
                scanf("%d",&tmp);
                t[0].push_back(tmp);
        }

        //printf("enter the crossing time of line 2");
        for(i=0;i<n-1;i++)
        {
                scanf("%d",&tmp);
                t[1].push_back(tmp);
        }

        //printf("enter the exit points");
        scanf("%d %d",&x[0],&x[1]);

        f[0].push_back(e[0] + a[0][0]);
        f[1].push_back( e[1] + a[1][0]);
        l[0].push_back(0);
        l[1].push_back(1);
int j=0;
        for(j=1;j<n;j++)
        {
                if(f[0][j-1] + a[0][j] < f[1][j-1] + t[1][j-1] + a[0][j])
                {
                        f[0].push_back(f[0][j-1] + a[0][j]);
                        l[0].push_back(0);
                }
                else
                {
                        f[0].push_back(f[1][j-1] + t[1][j-1] + a[0][j]);
                        l[0].push_back(1);
                }

                if(f[1][j-1] + a[1][j] < f[0][j-1] + t[0][j-1] + a[1][j])
                {
                        f[1].push_back(f[1][j-1] + a[1][j]);
                        l[1].push_back(1);
                }
                else
{
                        f[1].push_back(f[0][j-1] + t[0][j-1] + a[1][j]);
                        l[1].push_back(0);
                }
        }

        if(f[0][n-1] + x[0] < f[1][n-1] + x[1])
        {
                fmin = f[0][n-1] + x[0];
                lL = 0;
        }
        else
        {
                fmin = f[1][n-1] + x[1];
                lL = 1;
        }

        printf("%d\n",fmin);
        print_stat(l,lL,n-1);
        printf("%d",lL);
}