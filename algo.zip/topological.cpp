#include<iostream>
#include<stdio.h>
using namespace std;
#define INF 1000007

int tim,n;
enum color{white, grey, black};
int st[10],top=-1;

struct vert
{
        int ind;
        int color;
        int pred;
        int d;
        int f;
};


void dfs_visit(int a[30][30], int ind,struct vert *v)
{
        tim += 1;
        v[ind].d = tim;
        v[ind].color = grey;
        int i;
        for(i=0;i<n;i++)
        {
                if(a[ind][i] == 1)
                {
                        //printf("dfs");
                        if(v[i].color == white)
                                dfs_visit(a,i,v);
                }
        }
        v[ind].color = black;
        tim += 1;
        top++;
        st[top] = ind;
        //printf("%d %d\n",ind,tim);
 v[ind].f = tim;
}

int main()
{
        struct vert v[30];
        int a[30][30],i,j;
        scanf("%d",&n);
        for(i=0;i<n;i++)
        {
                for(j=0;j<n;j++)
                        scanf("%d",&a[i][j]);
        }

        for(i=0;i<n;i++)
        {
                v[i].ind = i;
                v[i].color = white;
        }
        tim =1;
 for(i=0;i<n;i++)
        {
                if(v[i].color ==white)
                {
                        dfs_visit(a,i,v);
                        int j;
                        for(j=top;j>=0;j--)
                        {
                                printf("%d",st[j]);
                        }
                        top = -1;
                        printf("\n");
                }
        }
}