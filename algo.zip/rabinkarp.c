#include<stdio.h>
#include<math.h>
#include<string.h>
#define Q 10000001
int main()
{
        char t[20],s[20];
        printf("enter the sequence:");
        scanf("%s",s);
        printf("enter the string:");
        scanf("%s",t);

        int d = 10;
        int m = strlen(s);
        int n = strlen(t);
        int h = ((int)pow(d,m-1))%Q;
        int i=0;
        int p =0;
        int t0 = 0;

        for(i=0;i<m;i++)
        {
                p = (d*p + s[i] - '0')%Q;
                t0 = (d*t0 + t[i]-'0')%Q;
        }

        //printf("%d %d",n,m);
        for(i=0;i<=n-m;i++)
        {
                printf("p = %d t0 = %d\n",p,t0);
                if(p == t0)
                {
                        //printf("yeah");
                        int j=0;
                        for(j=0;j<m;j++)
                        {
                                if(s[j] != t[i+j])
                                {
                                        break;
                                }
                        }
                        if(j>=m)
                        {
   printf("string matched at %d",i);
                        }
                }

                if(i<n-m)
                {
                        t0 = (d*(t0 - h*(t[i] - '0')) + t[i+m]-'0')%Q;
                }
        }
}