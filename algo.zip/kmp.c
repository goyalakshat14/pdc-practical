#include<stdio.h>
#include<string.h>
void prefix_func(char p[],int pt[])
{
        int m = strlen(p);
        pt[0]=-1;
        int k =-1;
        int q=0;
        for(q=1;q<m;q++)
        {
                printf("re4ached here %d %d\n",k,q);
                while(k>=0 && p[k+1]!=p[q])
                {
                        //printf("hi%d %d\n",k,q);
                        k = pt[k];

                }
                //printf("reahec here\n");
                if(p[k+1]==p[q])
                {
                        //printf("they matched\n");
                        k = k+1;
                }
                //printf("aaslfjsakf\n");
                pt[q] = k;
        }
}
int main()
{
        char t[100],p[20];
        int pt[100],m,n;
        scanf("%s",t);
        scanf("%s",p);
        //printf("processing started\n");
        n = strlen(t);
        m = strlen(p);
        //printf("reached here\n");
        prefix_func(p,pt);
        int q =-1,i;
        for(i=0;i<n;i++)
        {
                while(q>=0 && p[q+1]!=t[i])
                {
                  q = pt[q];
                }
                if(p[q+1] == t[i])
                {
                        printf("it matched\n");
                        q++;
                }

                if(q==m-1)
                {
                        printf("pattern occur at %d\n",i-m+1);
                        q = pt[q];
                }
        }
}