#include<iostream>
#include<vector>
#include<stdio.h>
using namespace std;
#define INF 10000007
int m[20][20],a[20][20]={-2};
void print(int i,int j)
{
        if(i==j)
                printf("a%d",i);
        else
        {
        printf("(");
        print(i,a[i][j]);
        print(a[i][j]+1,j);
        printf(")");
        }
}
int main()
{
        int i,j,l,n,k;
        int p[20];
        scanf("%d",&n);
        for(i=0;i<n;i++)
        {
                scanf("%d",&p[i]);
        }
        for(i=0;i<n;i++)
        {
                //scanf("%d",&a[i]);
                m[i][i] = 0;
        }

        for(l=2;l<n;l++)
        {
                for(i=1;i<=n-l+1;i++)
                {
                        int j = i+l-1;
                        m[i][j] = INF;
 for(k=i;k<j;k++)
                        {
                                int q = m[i][k] + m[k+1][j] + p[i-1]*p[k]*p[j];
                                if(q<m[i][j])
                                {
                                        m[i][j] = q;
                                        a[i][j] = k;
                                }
                        }
                }
        }
        /*
        for(i=1;i<n;i++)
        {
                for(j=1;j<n;j++)
                        printf("%d ",a[i][j]);
                printf("\n");
        }
*/
        ///*
//printf("(");
        //printf("%d",1);
        print(1,n-1);
        //printf("%d",n-1);
        //printf(")");
        printf("%d\n",m[1][n-1]);
        //*/
}