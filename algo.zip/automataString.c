#include<stdio.h>
#include<string.h>

int min(int a,int b)
{
        if(a>b)
                return b;
        else
                return a;
}

compute_transition_function(char p[],int delta[][10])
{
        int m = strlen(p),q=0,a;
        for(q=0;q<=m;q++)
        {
                for(a=1;a<10;a++)
                {
                        int k = min(m,q+1);
                        char temp1[100];

                        strcpy(temp1,p);
                        temp1[k] = '\0';

                        char temp2[100];
                        strcpy(temp2,p);
                        temp2[k-1] = a+'0';
                        temp2[k] = '\0';

                        printf("\n actually \n");
                        char *temp = (temp2);
                        while(1)
                        {
                                int len = strlen(temp2);
                                //printf("pre %s  suff %s temp %s k = %d q=%d\n",temp1,temp2,temp,k,q);
                                if(strcmp(temp1,temp) == 0)
                                        break;
                                k = k-1;
                                if(k==0)
                                        break;
                                temp = (temp + 1);
                                temp1[k] = '\0';
                        }
			delta[q][a] = k;
 			printf("\ntable %d %d %d\n",q,a,k);
                }
        }
	printf("transisoint complete\n");
}

finite_automata_str(char t[],int delta[][10],int m)
{
        int n = strlen(t);
        int q=0,i=0;
        for(i =0;i<n;i++)
        {
                q = delta[q][t[i]-'0'];
                if(m == q)
                {
                        printf("match occurs with shift %d",i-m+1);
                }
        }
}
int main()
{
        char p[100],t[100];
        int delta[100][10];
        printf("enter the pattern : ");
        scanf("%s",p);

        printf("enter the string : ");
        scanf("%s",t);

        int m = strlen(p);
        compute_transition_function(p,delta);

        finite_automata_str(t,delta,m);
}
