#include<stdio.h>
#include<mpi.h>
#include<malloc.h>

int main(int argc,char *argv[])
{
	int rank,size,n,i;
	int *arr;
	int val,temp_val;
	MPI_Status status;
	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD,&size);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	
	if(rank == 0)
	{
		arr = (int *)malloc(size*sizeof(int));
		for(i=0;i<size;i++)
		scanf("%d",&arr[i]);
		for(i=0;i<size;i++)
		printf("%d ",arr[i]);
	}	
	
	MPI_Scatter(arr,1,MPI_INT,&val,1,MPI_INT,0,MPI_COMM_WORLD);
	
	printf("%d %d\n",rank,val);
	
	for(i=0;i<size;i++)
	{
		if(i%2 == 0)
		{
			if(rank%2 == 0 && rank+1<size)
			{
				MPI_Send(&val,1,MPI_INT,rank+1,0,MPI_COMM_WORLD);
				MPI_Recv(&temp_val,1,MPI_INT,rank+1,1,MPI_COMM_WORLD,&status);
				if(temp_val<val)
				val=temp_val;
			}	
			else if(rank%2 == 1 && rank-1>=0)
			{
				MPI_Send(&val,1,MPI_INT,rank-1,1,MPI_COMM_WORLD);				
				MPI_Recv(&temp_val,1,MPI_INT,rank-1,0,MPI_COMM_WORLD,&status);
				if(temp_val>val)
				val = temp_val;
				//val = temp_val;
			}
		}
		else
		{
			if(rank%2 == 1 && rank+1<size)
			{
				MPI_Send(&val,1,MPI_INT,rank+1,0,MPI_COMM_WORLD);
				MPI_Recv(&temp_val,1,MPI_INT,rank+1,1,MPI_COMM_WORLD,&status);
				if(temp_val<val)
				val = temp_val;
			}
			else if(rank%2 == 0 && rank-1>=0)
			{					
				MPI_Send(&val,1,MPI_INT,rank-1,1,MPI_COMM_WORLD);
				MPI_Recv(&temp_val,1,MPI_INT,rank-1,0,MPI_COMM_WORLD,&status);
				if(temp_val>val)
				val = temp_val;
				//val = temp_val;
			}
		}
	
		MPI_Barrier(MPI_COMM_WORLD);
	}
	
	MPI_Gather(&val,1,MPI_INT,arr,1,MPI_INT,0,MPI_COMM_WORLD);

	MPI_Barrier(MPI_COMM_WORLD);
	if(rank == 0)
	{
		for(i=0;i<size;i++)
		{
			printf("%d ",arr[i]);
		}
	}
	MPI_Finalize();
	return 0;
}
