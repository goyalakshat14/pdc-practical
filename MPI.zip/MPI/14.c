#include<mpi.h>
#include<math.h>
#include<stdio.h>

int shuffle(int a,int n)
{
	int f = 0;
	if(a & (n>>1))
	{
		f = 1;
	}
	a = a<<1;
	a = a%n;
	a = a|f;
	return a;
}

int shuffle1(int a,int n)
{
	int f = 0;
	if(a&1)
		f = 1;
	a = a>>1;
	if(f)
		a = a|(n>>1);
	return a;
}

int exchange(int r)
{
	if(r&1)
		return r-1;
	else
		return r+1;
}

int main(int argc,char *argv[])
{
	int rank,size,k;
	int arr[] = {2,1,3,1,2,1,5,3};
	int val,s,temp_val,temp,temp1,i;
	
	MPI_Status status;
	MPI_Init(&argc,&argv);
	MPI_Comm_size(MPI_COMM_WORLD,&size);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);

	val = arr[rank];
	s = size;
	/*if(rank == 0)
	{
		for(i=0;i<8;i++)
		{
			temp = shuffle(i,size);
			printf("%d %d ",i,temp);
			temp = shuffle1(i,size);
			printf("%d \n",temp);
		}
	}*/
	
	while(s>0)
	{
		if(rank!=0 && rank!=7)
		{		
			MPI_Send(&val,1,MPI_INT,shuffle(rank,size),0,MPI_COMM_WORLD);				
			MPI_Recv(&temp_val,1,MPI_INT,shuffle1(rank,size),0,MPI_COMM_WORLD,&status);
			val = temp_val;
		}
		MPI_Send(&val,1,MPI_INT,exchange(rank),0,MPI_COMM_WORLD);
		MPI_Recv(&temp_val,1,MPI_INT,exchange(rank),0,MPI_COMM_WORLD,&status);
		val = val+temp_val;		
		s = s>>1;
		MPI_Barrier(MPI_COMM_WORLD);
	}
		
	printf("%d %d \n",rank,val);
		
	MPI_Finalize();
	return 0;
}
